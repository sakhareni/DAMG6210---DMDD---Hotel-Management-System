import tkinter as tk
from tkinter import messagebox
import pyodbc

def db_connect():
    """Connect to the SQL Server database."""
    try:
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};'
            'SERVER=LAPTOP-BD359SRP;'
            'DATABASE=HotelCalifornia;'
            'Trusted_Connection=yes;'
        )
        return conn
    except Exception as e:
        messagebox.showerror("Connection Error", str(e))

def create_record():
    """Function to add a new record to the Employee table."""
    conn = db_connect()
    if conn:
        cursor = conn.cursor()
        try:
            # Insert into Employee without specifying Employee_ID
            cursor.execute('''
                INSERT INTO Employee (Name, Email, Phone, Designation, Address, Hiring_Date)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (name.get(), email.get(), phone.get(), designation.get(), address.get(), hiring_date.get()))
            conn.commit()
            messagebox.showinfo("Success", "Record created successfully")
        except Exception as e:
            messagebox.showerror("Error", str(e))
        finally:
            conn.close()

def read_record():
    """Function to read and display a record."""
    conn = db_connect()
    if conn:
        cursor = conn.cursor()
        try:
            cursor.execute('SELECT * FROM Employee WHERE Employee_ID = ?', (e_id.get(),))
            record = cursor.fetchone()
            if record:
                name.set(record[1])
                email.set(record[2])
                phone.set(record[3])
                designation.set(record[4])
                address.set(record[5])
                hiring_date.set(record[6])
            else:
                messagebox.showinfo("Not Found", "No record found")
        except Exception as e:
            messagebox.showerror("Error", str(e))
        finally:
            conn.close()

def update_record():
    """Function to update a record."""
    conn = db_connect()
    if conn:
        cursor = conn.cursor()
        try:
            cursor.execute('''
                UPDATE Employee
                SET Name = ?, Email = ?, Phone = ?, Designation = ?, Address = ?, Hiring_Date = ?
                WHERE Employee_ID = ?
            ''', (name.get(), email.get(), phone.get(), designation.get(), address.get(), hiring_date.get(), e_id.get()))
            conn.commit()
            if cursor.rowcount > 0:
                messagebox.showinfo("Success", "Record updated successfully")
            else:
                messagebox.showinfo("Not Found", "No record found to update")
        except Exception as e:
            messagebox.showerror("Error", str(e))
        finally:
            conn.close()

def delete_record():
    """Function to delete a record."""
    conn = db_connect()
    if conn:
        cursor = conn.cursor()
        try:
            cursor.execute('DELETE FROM Employee WHERE Employee_ID = ?', (e_id.get(),))
            conn.commit()
            if cursor.rowcount > 0:
                messagebox.showinfo("Success", "Record deleted successfully")
            else:
                messagebox.showinfo("Not Found", "No record found to delete")
        except Exception as e:
            messagebox.showerror("Error", str(e))
        finally:
            conn.close()

# Create the main window
root = tk.Tk()
root.title("Database Management System")

# Create buttons for CRUD operations
create_button = tk.Button(root, text="Create Record", command=create_record)
read_button = tk.Button(root, text="Read Record", command=read_record)
update_button = tk.Button(root, text="Update Record", command=update_record)
delete_button = tk.Button(root, text="Delete Record", command=delete_record)

create_button.grid(row=0, column=0, padx=10, pady=10)
read_button.grid(row=0, column=1, padx=10, pady=10)
update_button.grid(row=0, column=2, padx=10, pady=10)
delete_button.grid(row=0, column=3, padx=10, pady=10)

# Create and layout form fields
tk.Label(root, text="Employee ID").grid(row=1, column=0)
tk.Label(root, text="Name").grid(row=2, column=0)
tk.Label(root, text="Email").grid(row=3, column=0)
tk.Label(root, text="Phone").grid(row=4, column=0)
tk.Label(root, text="Designation").grid(row=5, column=0)
tk.Label(root, text="Address").grid(row=6, column=0)
tk.Label(root, text="Hiring Date").grid(row=7, column=0)

e_id = tk.StringVar()
name = tk.StringVar()
email = tk.StringVar()
phone = tk.StringVar()
designation = tk.StringVar()
address = tk.StringVar()
hiring_date = tk.StringVar()

tk.Entry(root, textvariable=e_id).grid(row=1, column=1, padx=10, pady=2)
tk.Entry(root, textvariable=name).grid(row=2, column=1, padx=10, pady=2)
tk.Entry(root, textvariable=email).grid(row=3, column=1, padx=10, pady=2)
tk.Entry(root, textvariable=phone).grid(row=4, column=1, padx=10, pady=2)
tk.Entry(root, textvariable=designation).grid(row=5, column=1, padx=10, pady=2)
tk.Entry(root, textvariable=address).grid(row=6, column=1, padx=10, pady=2)
tk.Entry(root, textvariable=hiring_date).grid(row=7, column=1, padx=10, pady=2)

# Start the GUI event loop
root.mainloop()
